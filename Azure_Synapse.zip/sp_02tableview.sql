USE gold_db
go
CREATE OR ALTER PROC createSQLserverIessView_goId @viewname	 nvarchar(100)
AS
BEGIN

DECLARE @statement VARCHAR(MAX)

	SET @statement = N'CREATE OR ALTER VIEW' + QUOTENAME(@viewname) + ' AS
		SELECT *
		FROM
			OPENROWSET(
			BULK  ''https://02dlgen2.dfs.core.windows.net/gold/SalesLT/' + @viewname + '/'',
			FORMAT = ''DELTA''
		) as [result]
	'
		
EXEC (@statement)
END
GO